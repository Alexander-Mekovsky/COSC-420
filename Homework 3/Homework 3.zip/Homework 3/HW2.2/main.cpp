//Shell Sort Parallelization 2

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>
#include <ctime>
#include <cmath>
#include <random>
#include <cstring>

template<class T>
void seqShellSort(T arr[], int n, int commsz)
{
    register int i, j, hCnt, h;
    int increments[20], k;
    
    for(i = 0, h = commsz; h < n; i++)
    {
        increments[i] = h;
        h = (1/3) * h;
    }
    
    for(i--; i >= 0; i--)
    {
        h = increments[i];
        
        for(hCnt = h; hCnt < 2 * h; hCnt++)
        {
            for(j = hCnt; j < n; )
            {
                T temp = arr[j];
                k = j;
                while(k - h >= 0 && temp < arr[k - h])
                {
                    arr[k] = arr[k - h];
                    k -= h;
                }
                arr[k] = temp;
                j += h;
            }
        }
    }
}

using namespace std;

int main(void) {
	int commsz, rank, n; 
    double starttime, endtime;
    
    random_device rd;
    mt19937 gen(rd());
    uniform_real_distribution<> rng(0, 100000000);

	/* Start up MPI */
	MPI_Init(NULL, NULL);

	/* Get the number of processes */
	MPI_Comm_size(MPI_COMM_WORLD, &commsz);

	/* Get my rank among all the processes */
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        
    srand(time(0) + rank);
    
    double seqtime, paraTime;
    
    if(rank == 0) 
    {
		cout << "Input size of array: ";
		cin >> n;
	}
	
	MPI_Barrier(MPI_COMM_WORLD);
    
    int *arr = NULL;
    int *seqArr = NULL;
    int *parArr = NULL;
    if(rank == 0)
    {
        arr = new int[n];
        seqArr = new int[n];
        parArr = new int[n];
        for (int i = 0; i < n; i++)
        {
            arr[i] = rng(gen);
        }
    
        for(int i = 0; i < n; i++)
        {  
            seqArr[i] = arr[i];
            parArr[i] = arr[i];
        }   
    }
    
    MPI_Barrier(MPI_COMM_WORLD);
    
    if(rank == 0)
    {
        starttime = MPI_Wtime();
        seqShellSort(seqArr, n, commsz);
        endtime = MPI_Wtime();
        seqtime = endtime-starttime;
        cout << "\n-----Sequential-----\n" << endl;
        printf("Shell Sort sequentially done in %.8f sec.\n", seqtime);
    }
     
    MPI_Barrier(MPI_COMM_WORLD);
    
    starttime = MPI_Wtime();
    
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    int *sortPar = new int[n];
    
    register int i, j, hCnt, h;
    int increments[20], k;
    
    for(i = 0, h = commsz; h > 2; i++)
    {
        increments[i] = h;
        h = (1/3) * h;
    }
    
    for(i--; i >= 0; i--)
    {
        h = increments[i];
        
        for(hCnt = h; hCnt < 2 * h; hCnt++)
        {
            for(j = hCnt; j < n; )
            {
                int temp = parArr[j];
                k = j;
                while(k - h >= 0 && temp < parArr[k - h])
                {
                    parArr[k] = parArr[k - h];
                    k -= h;
                }
                parArr[k] = temp;
                j += h;
            }
        }
    }
    if(rank == 0)
    {
        MPI_Reduce(sortPar, parArr, n, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
        endtime = MPI_Wtime();
        paraTime = endtime-starttime;
        cout << "\n-----Parallel-----\n" << endl;
        printf("Shell Sort parallel done in %.8f sec.\n", paraTime);
    }
    
    MPI_Finalize();
    
    delete[] arr;
    delete[] seqArr;
    delete[] parArr;
    
    return 0;
}
