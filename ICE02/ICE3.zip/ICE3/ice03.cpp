//Alexander Mekovsky and Gavin Beauchamp

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>
#include <ctime>
#include <cmath>
#include <random>
#include <cstring>

using namespace std;

int main(void) {
	int commsz, rank, n; 
    double seqSum = 0;
    double parSum = 0;
    double starttime, endtime;
    
    random_device rd;
    mt19937 gen(rd());
    uniform_real_distribution<> rng(-1.0, 1.0);

	/* Start up MPI */
	MPI_Init(NULL, NULL);

	/* Get the number of processes */
	MPI_Comm_size(MPI_COMM_WORLD, &commsz);

	/* Get my rank among all the processes */
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    
    srand(time(0) + rank);
    
    if (rank == 0) {
		cout << "Input size of vectors: ";
		cin >> n;
	}
	
	MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    
    double *v = new double[n];
    double *w = new double[n];
    double *seqV = new double[n];
    double *seqW = new double[n];
    double *parV = new double[n];
    double *parW = new double[n];
    
    if(rank == 0)
    {
        for (int i = 0; i < n; i++)
        {
            v[i] = rng(gen);
            w[i] = rng(gen);
        }
    
        for(int i = 0; i < n; i++)
        {  
            seqV[i] = v[i];
            seqW[i] = w[i];
            parV[i] = v[i];
            parW[i] = w[i];
        }   
    }
    if(rank == 0)
    {
        double temp = 0;
        starttime = MPI_Wtime();
        for(int i = 0; i < n; i++)
        {
            temp = v[i] * w[i];
            seqSum += temp;
        }
        endtime = MPI_Wtime();
        printf("Dot Product sequentially = %.8f done in %.8f sec.\n", seqSum, endtime - starttime);
    }
    if(rank != 0)
    {
        
    }
    if(rank != 0)
    {
        
    }
    
	MPI_Finalize();
    
    delete[] v;
    delete[] w;
    delete[] seqV;
    delete[] seqW;
    delete[] parV;
    delete[] parW;
    
	return 0;
}
